Floodman local migration templates

Required: contacts.csv, properties.csv, estimates.csv, estimate_lines.csv, invoices.csv, payments.csv.
Optional but supported: documents.csv, notes.csv and referenced files.
Use integer cents for money. Preserve untouched source exports separately.
Imported invoices are historical archive records and do not start reminders or create Square links.
