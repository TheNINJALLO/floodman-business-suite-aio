from __future__ import annotations

import os
import json
import re
import shutil
import socket
import tempfile
import threading
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent


class FakeProviders:
    async def lab_state(self) -> dict[str, Any]:
        return {
            "demo_job_id": "ui-smoke-job",
            "job": {},
            "gauzy_contacts": {"items": []},
            "properties": [],
            "gauzy_invoices": {"items": []},
            "gauzy_payments": {"items": []},
            "square_invoices": [],
            "envelopes": [],
            "staff_alerts": [],
            "ar_cases": [],
            "sms_messages": [],
            "messages": [],
            "message_threads": [],
            "emails": [],
            "imported_documents": [],
            "notes": [],
        }

    async def competitor_targets(self) -> list[dict[str, Any]]:
        return []

    async def competitor_reports(self) -> list[dict[str, Any]]:
        return []

    async def gauzy_context(self) -> dict[str, Any]:
        return {
            "tenant_id": "ui-smoke-tenant",
            "organization_id": "ui-smoke-organization",
            "from_organization_id": "ui-smoke-organization",
            "sync_enabled": False,
        }

    def square_payment_configuration(self) -> dict[str, Any]:
        return {
            "environment": "local",
            "application_id": "",
            "location_id": "local-square-location",
            "sdk_url": "",
            "live": False,
            "local_mock": True,
        }


def seed(main: Any) -> dict[str, Any]:
    owner = main.store.create_owner("UI Smoke Owner", "owner@example.test", "Floodman-Test-2026!")
    workspace = main.ensure_roomflow_workspaces(main.store, actor_id=str(owner["id"]))[0]
    contact = main.store.create_record(
        "contacts",
        {
            "name": "Alex Carter",
            "first_name": "Alex",
            "last_name": "Carter",
            "email": "alex@example.test",
            "phone": "2315550148",
            "status": "ACTIVE_CUSTOMER",
            "street": "1847 Pine Ridge Lane",
            "city": "Traverse City",
            "state": "MI",
            "postal_code": "49686",
        },
        actor_id=owner["id"],
    )
    property_record = main.store.create_record(
        "properties",
        {
            "contact_id": contact["id"],
            "name": "Carter Residence",
            "property_name": "Carter Residence",
            "property_type": "Residential",
            "service_street": "1847 Pine Ridge Lane",
            "service_city": "Traverse City",
            "service_state": "MI",
            "service_postal_code": "49686",
        },
        actor_id=owner["id"],
    )
    section = {"id": "section-1", "name": "Waterproofing", "description": "", "sort_order": 0}
    line = {
        "id": "line-1",
        "section_id": "section-1",
        "section_name": "Waterproofing",
        "name": "Interior perimeter drainage",
        "description": "Install a customer-approved drainage system.",
        "quantity": 10,
        "unit": "LF",
        "unit_price_cents": 4500,
        "line_total_cents": 45000,
        "selected": True,
        "sort_order": 0,
    }
    common = {
        "contact_id": contact["id"],
        "property_id": property_record["id"],
        "title": "Carter basement waterproofing",
        "currency": "USD",
        "sections": [section],
        "line_items": [line],
        "total_cents": 45000,
        "terms": "Payment is due according to the signed agreement.",
    }
    estimate = main.store.create_record(
        "estimates",
        {
            **common,
            "estimate_number": "EST-UI-001",
            "status": "ACCEPTED",
            "deposit_type": "PERCENT",
            "deposit_percent": 30,
            "deposit_due_stage": "IMMEDIATELY",
            "deposit_payable": True,
        },
        actor_id=owner["id"],
    )
    invoice = main.store.create_record(
        "invoices",
        {
            **common,
            "invoice_number": "INV-UI-001",
            "status": "PARTIALLY_PAID",
            "balance_cents": 30000,
            "paid_cents": 15000,
            "collection_mode": "PAYMENT_PAGE",
        },
        actor_id=owner["id"],
    )
    payment = main.store.create_record(
        "payments",
        {
            "invoice_id": invoice["id"],
            "contact_id": contact["id"],
            "amount_cents": 15000,
            "currency": "USD",
            "status": "COMPLETED",
            "method": "CARD",
            "payment_date": "2026-08-12",
            "processor_payment_id": "ui-smoke-payment",
            "card_brand": "VISA",
            "last_4": "1111",
        },
        actor_id=owner["id"],
    )
    estimate = main._ensure_public_document("estimate", estimate, actor_id=owner["id"])
    invoice = main._ensure_public_document("invoice", invoice, actor_id=owner["id"])
    roomflow_job = main.store.create_record(
        "roomflow_jobs",
        {
            "id": "browser-capture-job",
            "roomflow_job_id": "browser-upstream-job",
            "workspace_id": workspace["id"],
            "contact_id": contact["id"],
            "property_id": property_record["id"],
            "estimate_id": estimate["id"],
            "job_name": "Browser Capture Job",
            "snapshot": {"rooms": [], "costing": {"customItems": []}},
            "source": "TEST_FIXTURE",
        },
        actor_id=owner["id"],
    )
    return {"owner": owner, "contact": contact, "property": property_record, "estimate": estimate, "invoice": invoice, "payment": payment, "workspace": workspace, "roomflow_job": roomflow_job}


def route_smoke(main: Any, records: dict[str, Any]) -> None:
    from fastapi.testclient import TestClient

    client = TestClient(main.app, follow_redirects=False)
    login = client.post(
        "/login",
        data={"email": "owner@example.test", "password": "Floodman-Test-2026!", "next": "/office/desktop"},
    )
    assert login.status_code == 303
    assert "floodman_session" in client.cookies

    pages = [
        "/setup", "/office", "/office/desktop", "/office/mobile?mobile=1", "/office/apps", "/office/settings",
        "/office/linking", "/office/imports", "/office/contacts", "/office/properties",
        "/office/catalog", "/office/estimates", "/office/estimates/new", "/office/invoices",
        "/office/payments", "/office/payment-settings", "/office/documents", "/office/tasks",
        "/office/notes", "/office/time", "/office/members", "/office/messages",
        "/office/receivables", "/office/intelligence", "/office/alerts", "/office/platform",
        "/office/signing", "/office/roomflow", "/office/roomflow/import",
        f"/office/contacts/{records['contact']['id']}",
        f"/office/contacts/{records['contact']['id']}/edit",
        f"/office/properties/{records['property']['id']}",
        f"/office/properties/{records['property']['id']}/edit",
        f"/office/estimates/{records['estimate']['id']}",
        f"/office/estimates/{records['estimate']['id']}/edit",
        f"/office/estimates/{records['estimate']['id']}/take-payment",
        f"/office/invoices/{records['invoice']['id']}",
        f"/office/invoices/{records['invoice']['id']}/edit",
        f"/office/invoices/{records['invoice']['id']}/take-payment",
    ]
    for path in pages:
        response = client.get(path)
        assert response.status_code == 200, f"{path} returned {response.status_code}: {response.text[:300]}"
        assert "Floodman" in response.text, f"{path} did not render a Floodman page"

    settings_page = client.get("/office/settings")
    assert "OWNER START HERE" in settings_page.text
    assert "Everyday setup" in settings_page.text and "Advanced connections" in settings_page.text
    setup_page = client.get("/setup")
    assert "Eastern Time (Detroit)" in setup_page.text
    assert "name='timezone'" in setup_page.text and "name='timezone' value=" not in setup_page.text
    original_profile = main.store.profile()
    rejected_timezone = client.post(
        "/setup/profile",
        data={"company_name": "UI Smoke", "timezone": "UTC", "state": "MI"},
    )
    assert rejected_timezone.status_code == 303
    assert main.store.profile() == original_profile, "invalid time zone changed the company profile"
    invites_before = len(main.store.list_invites())
    rejected_owner = client.post(
        "/office/members/invite",
        data={"name": "Unsafe Owner", "email": "unsafe-owner@example.test", "role": "OWNER"},
    )
    assert rejected_owner.status_code == 303
    assert len(main.store.list_invites()) == invites_before, "a second owner invitation was accepted"
    workspaces_before = len(main.store.records("roomflow_workspaces"))
    rejected_workspace = client.post(
        "/office/api/roomflow/workspaces",
        json={"name": "Wrong Time Company", "timezone": "UTC"},
    )
    assert rejected_workspace.status_code == 422
    assert len(main.store.records("roomflow_workspaces")) == workspaces_before
    original_import = main.import_roomflow_supabase
    captured_import: dict[str, str] = {}
    try:
        def fake_import(_store: Any, *, email: str, password: str, actor_id: str, **_kwargs: Any) -> dict[str, Any]:
            captured_import.update(email=email, password=password, actor_id=actor_id)
            return {"counts": {"jobs": 2}, "workspaces": [{"id": "workspace-test"}]}

        main.import_roomflow_supabase = fake_import
        imported = client.post(
            "/office/roomflow/import",
            data={"email": "old-roomflow@example.test", "password": "Temporary-RoomFlow-Password"},
        )
        assert imported.status_code == 303
        assert captured_import["email"] == "old-roomflow@example.test"
        assert "Temporary-RoomFlow-Password" not in str(main.store.snapshot())
    finally:
        main.import_roomflow_supabase = original_import

    for kind in ("estimate", "invoice"):
        record = records[kind]
        token = record["public_token"]
        public_page = client.get(f"/customer/{kind}/{token}")
        assert public_page.status_code == 200
        assert "Created by Josh Aldrich" not in public_page.text or "Floodman" in public_page.text
        pdf = client.get(f"/customer/{kind}/{token}/pdf")
        assert pdf.status_code == 200
        assert pdf.headers["content-type"].startswith("application/pdf")
        assert pdf.content.startswith(b"%PDF-")

    pay = client.get(f"/customer/pay/{records['invoice']['public_token']}")
    assert pay.status_code == 200 and "secure payment" in pay.text.lower()
    receipt = client.get(
        f"/customer/receipt/{records['invoice']['public_token']}?payment={records['payment']['id']}"
    )
    assert receipt.status_code == 200 and "PAYMENT RECEIPT" in receipt.text
    legacy = client.get("/office/gauzy")
    assert legacy.status_code in {302, 303, 307, 308}


def static_overlay_contracts() -> None:
    sources = {
        "pwa_js": (ROOT / "pwa" / "floodman-pwa.js").read_text(encoding="utf-8"),
        "pwa_css": (ROOT / "pwa" / "floodman-pwa.css").read_text(encoding="utf-8"),
        "panel_js": (ROOT / "roomflow" / "floodman-panel.js").read_text(encoding="utf-8"),
        "panel_css": (ROOT / "roomflow" / "floodman-panel.css").read_text(encoding="utf-8"),
        "capture_js": (ROOT / "roomflow" / "capture" / "roomflow-capture.js").read_text(encoding="utf-8"),
        "capture_css": (ROOT / "roomflow" / "capture" / "roomflow-capture.css").read_text(encoding="utf-8"),
        "legacy_js": (ROOT / "roomflow" / "floodman-roomflow.js").read_text(encoding="utf-8"),
        "legacy_css": (ROOT / "roomflow" / "floodman-roomflow.css").read_text(encoding="utf-8"),
        "hub_js": (ROOT / "hub" / "hub.js").read_text(encoding="utf-8"),
        "launcher": (REPO / "launcher" / "mobile-start.sh").read_text(encoding="utf-8"),
        "deployment": (REPO / "deployment" / "releases" / "mobile-start-v4.7.0.sh").read_text(encoding="utf-8"),
        "nginx": (ROOT / "aio" / "nginx.conf.template").read_text(encoding="utf-8"),
        "office": (ROOT / "office-console" / "app" / "main.py").read_text(encoding="utf-8"),
    }
    assert "fm-pwa-toast-dismiss" in sources["pwa_js"] and "Dismiss notification" in sources["pwa_js"]
    assert ".fm-pwa-toast-dismiss" in sources["pwa_css"]
    assert "fm-rf-panel-dismissed" in sources["panel_js"]
    assert "floodman_roomflow_quick_start_dismissed_v1" in sources["panel_js"]
    assert "Dismiss quick start" in sources["panel_js"] and "Dismiss message" in sources["panel_js"]
    assert "params.get('catalog_sync') === '1'" in sources["panel_js"]
    assert "event.key === 'Escape'" in sources["panel_js"]
    assert "No separate RoomFlow account is required" in sources["panel_js"]
    assert "authOverlay.style.display = 'none'" in sources["panel_js"]
    assert "btn-more-create-company" in sources["panel_js"] and "changeWorkspace" in sources["panel_js"]
    assert "/office/api/roomflow/workspaces" in sources["office"]
    assert ":not(.fm-rf-panel-dismissed)" in sources["panel_css"]
    assert "RoomFlowCaptureBridgeV2" in sources["capture_js"] and "version: 2, sessionId, type, requestId" in sources["capture_js"]
    assert "encoded.count <= 256 * 1024" not in sources["capture_js"] and "serialized.length > 262144" in sources["capture_js"]
    assert "Start from a room template" in sources["capture_js"] and "Compare captured plan" in sources["capture_js"]
    assert "data-plan-vertex" in sources["capture_js"] and "data-lock-wall" in sources["capture_js"]
    assert "Camera-derived dimensions are estimates" in sources["capture_js"]
    assert "dialog.addEventListener('cancel'" in sources["capture_js"] and "closeDialog" in sources["capture_js"]
    assert "@media (max-width: 720px)" in sources["capture_css"] and "100dvh" in sources["capture_css"]
    assert "fmrf-close-icon" in sources["legacy_js"] and "aria-label','Close save dialog" in sources["legacy_js"]
    assert "e.key === 'Escape'" in sources["legacy_js"] and "fmrf-modal-open" in sources["legacy_css"]
    assert "aria-modal" in sources["hub_js"] and "Back to Floodman" in sources["hub_js"]
    assert "location = /api/auth/login" in sources["nginx"]
    assert "proxy_pass http://127.0.0.1:8700/office/api/erp/login" in sources["nginx"]
    assert "error_page 401 =302 /login?next=/roomflow/" in sources["nginx"]
    assert "floodmanLoginNext" in sources["office"] and "/login/erp-session" in sources["office"]
    for key in ("launcher", "deployment"):
        assert "floodman-dismiss-recovery" in sources[key]
        assert "event.key === 'Escape'" in sources[key]
        assert "Created by Josh Aldrich" in sources[key]
        assert "const pendingLoginKey = 'floodmanLoginNext'" in sources[key]
        assert "proxy_pass http://127.0.0.1:8700/office/api/erp/login" in sources[key]


def browser_executable() -> str | None:
    candidates = [
        shutil.which("msedge"), shutil.which("google-chrome"), shutil.which("chromium"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    ]
    return next((str(candidate) for candidate in candidates if candidate and Path(candidate).is_file()), None)


def build_browser_app(main: Any) -> Any:
    from fastapi import FastAPI
    from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

    app = FastAPI()

    files = {
        "/floodman-pwa.css": ROOT / "pwa" / "floodman-pwa.css",
        "/floodman-pwa.js": ROOT / "pwa" / "floodman-pwa.js",
        "/floodman-sw.js": ROOT / "pwa" / "floodman-sw.js",
        "/floodman-workspace.css": ROOT / "pwa" / "workspace-mode.css",
        "/manifest.webmanifest": ROOT / "pwa" / "manifest.webmanifest",
        "/hub.css": ROOT / "hub" / "hub.css",
        "/hub.js": ROOT / "hub" / "hub.js",
        "/roomflow/floodman-panel.css": ROOT / "roomflow" / "floodman-panel.css",
        "/roomflow/floodman-panel.js": ROOT / "roomflow" / "floodman-panel.js",
        "/roomflow/roomflow-capture.css": ROOT / "roomflow" / "capture" / "roomflow-capture.css",
        "/roomflow/roomflow-capture-geometry.js": ROOT / "roomflow" / "capture" / "roomflow-capture-geometry.js",
        "/roomflow/roomflow-capture.js": ROOT / "roomflow" / "capture" / "roomflow-capture.js",
        "/legacy-roomflow.css": ROOT / "roomflow" / "floodman-roomflow.css",
        "/legacy-roomflow.js": ROOT / "roomflow" / "floodman-roomflow.js",
    }
    for route, path in files.items():
        app.add_api_route(route, lambda path=path: FileResponse(path), methods=["GET"])

    @app.get("/floodman-brand/{name}")
    def brand(name: str) -> FileResponse:
        assert name in {"floodman-mark.svg", "floodman-wordmark.svg"}
        return FileResponse(ROOT / "hub" / "brand" / name)

    @app.get("/floodman-pwa-icons/{name}")
    def pwa_icon(name: str) -> FileResponse:
        path = ROOT / "pwa" / "icons" / name
        return FileResponse(path)

    @app.get("/office-health/live")
    def office_health() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": "4.7.0"})

    @app.get("/hub-fixture")
    def hub_fixture() -> HTMLResponse:
        return HTMLResponse("""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='/hub.css'></head><body><main><h1>Floodman ERP fixture</h1></main><script>window.FLOODMAN_HUB_CONFIG={officeUrl:location.origin,competitorUrl:location.origin+'/office/intelligence'};</script><script src='/hub.js'></script></body></html>""")

    @app.get("/roomflow/")
    def roomflow_fixture() -> HTMLResponse:
        workspace = main.store.records("roomflow_workspaces")[0]
        fixture_state = json.dumps({"currentJobName": "UI Fixture", "jobId": "browser-upstream-job", "floodmanRoomFlowJobId": "browser-capture-job", "workspaceId": workspace["id"], "organizationId": workspace["id"], "currentLevelId": "basement", "costing": {"customItems": []}})
        return HTMLResponse(f"""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='/roomflow/floodman-panel.css'><link rel='stylesheet' href='/roomflow/roomflow-capture.css'></head><body><main><h1>RoomFlow fixture</h1><canvas id='sketch-canvas' width='320' height='240'></canvas><div class='checklist-room-card'><h3>Active Workspaces</h3><p>Legacy account controls</p><select id='more-company-switcher'><option value=''>Select...</option></select><input id='more-new-company-name'><button id='btn-more-create-company'>Create</button><button onclick='RoomFlowAuth.signOut()'>Log Out from Account</button></div><button id='btn-refresh-shared-jobs'>Refresh Shared Jobs</button></main><div id='auth-overlay' class='hidden' style='display:none'>Separate RoomFlow account required</div><script>window.state={fixture_state};window.switchTab=function(){{}};window.RoomFlowAuth={{signOut:function(){{}}}};window.__legacyAccountPrompted=false;window.autosaveJob=function(){{}};window.draw=function(){{}};document.addEventListener('DOMContentLoaded',function(){{document.getElementById('btn-more-create-company').addEventListener('click',function(){{window.__legacyAccountPrompted=true;document.getElementById('auth-overlay').style.display='flex';}});}});</script><script src='/roomflow/floodman-panel.js'></script><script src='/roomflow/roomflow-capture-geometry.js'></script><script src='/roomflow/roomflow-capture.js'></script></body></html>""")

    @app.get("/legacy-roomflow")
    def legacy_roomflow_fixture() -> HTMLResponse:
        return HTMLResponse("""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='/legacy-roomflow.css'></head><body><main><h1>Legacy RoomFlow fixture</h1></main><script>window.state={currentJobName:'Legacy Fixture',costing:{customItems:[]}};</script><script src='/legacy-roomflow.js'></script></body></html>""")

    app.mount("/", main.app)
    return app


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


def browser_smoke(main: Any) -> None:
    executable = browser_executable()
    if not executable:
        print("Browser UI smoke skipped: no local Chromium-family executable")
        return

    import uvicorn
    from playwright.sync_api import sync_playwright

    port = free_port()
    server = uvicorn.Server(uvicorn.Config(build_browser_app(main), host="127.0.0.1", port=port, log_level="error", lifespan="off"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.time() + 10
    while not server.started and time.time() < deadline:
        time.sleep(0.05)
    assert server.started, "Browser fixture server did not start"
    base = f"http://127.0.0.1:{port}"
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=executable, headless=True)
            desktop = browser.new_context(viewport={"width": 1440, "height": 900})
            page = desktop.new_page()
            page.goto(base + "/login/local?next=/office/desktop")
            form = page.locator("form[action='/login']")
            form.locator("input[name='email']").fill("owner@example.test")
            form.locator("input[name='password']").fill("Floodman-Test-2026!")
            form.locator("button").click()
            page.wait_for_url(re.compile(r"/office/desktop"))

            desktop_pages = [
                "/setup", "/office/desktop?desktop=1", "/office/apps", "/office/settings", "/office/linking", "/office/imports",
                "/office/contacts", "/office/properties", "/office/catalog", "/office/estimates",
                "/office/estimates/new", "/office/invoices", "/office/payments", "/office/payment-settings",
                "/office/documents", "/office/tasks", "/office/notes", "/office/time", "/office/members",
                "/office/messages", "/office/receivables", "/office/intelligence", "/office/alerts",
                "/office/platform", "/office/signing", "/office/roomflow", "/office/roomflow/import",
            ]
            errors: list[str] = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            for path in desktop_pages:
                response = page.goto(base + path, wait_until="domcontentloaded")
                assert response and response.status == 200, f"desktop browser route failed: {path}"
                assert not page.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 2"), f"desktop horizontal overflow: {path}"

            page.goto(base + "/office/desktop?desktop=1", wait_until="domcontentloaded")
            page.evaluate("window.dispatchEvent(new Event('appinstalled'))")
            toast = page.locator("#fm-pwa-toast")
            toast.wait_for(state="visible")
            toast.locator(".fm-pwa-toast-dismiss").click()
            assert not toast.evaluate("node => node.classList.contains('is-visible')")

            hub_response = page.goto(base + "/hub-fixture", wait_until="domcontentloaded")
            page.wait_for_timeout(250)
            assert hub_response and hub_response.status == 200
            assert page.locator(".fm-hub-trigger").count() == 1, f"hub shell did not load: {errors}; {page.content()[:500]}"
            page.locator(".fm-hub-trigger").click()
            assert page.locator(".fm-hub-drawer").get_attribute("aria-hidden") == "false"
            page.keyboard.press("Escape")
            assert page.locator(".fm-hub-drawer").get_attribute("aria-hidden") == "true"
            page.locator(".fm-hub-trigger").click()
            page.get_by_role("button", name=re.compile("Floodman RoomFlow Estimator")).click()
            assert page.locator(".fm-hub-overlay").get_attribute("aria-hidden") == "false"
            page.locator(".fm-hub-overlay-close").click()
            assert page.locator(".fm-hub-overlay").get_attribute("aria-hidden") == "true"

            page.goto(base + "/roomflow/", wait_until="domcontentloaded")
            panel = page.locator("#fm-roomflow-panel")
            panel.wait_for(state="visible")
            capture_launch = page.locator("#fm-capture-launch")
            capture_launch.wait_for(state="visible")
            capture_launch.click()
            capture_dialog = page.locator("#fm-capture-dialog")
            capture_dialog.wait_for(state="visible")
            page.get_by_role("button", name="Enter room manually").click()
            page.locator("#fm-capture-manual-form input[name='name']").fill("Basement Recreation Room")
            page.locator("#fm-capture-next").click()
            assert "120 sq ft" in capture_dialog.inner_text()
            assert "44 ft" in capture_dialog.inner_text()
            first_wall = page.locator("[data-wall-length='0']")
            first_wall.fill("11")
            first_wall.press("Tab")
            page.get_by_role("button", name="Undo").click()
            assert "120 sq ft" in capture_dialog.inner_text()
            page.get_by_role("button", name="Redo").click()
            page.locator("#fm-capture-opening-form button[type='submit']").click()
            assert "door · wall 1" in capture_dialog.inner_text().lower()
            page.locator("#fm-capture-opening-form select[name='type']").select_option("window")
            page.locator("#fm-capture-opening-form input[name='width']").fill("2")
            page.locator("#fm-capture-opening-form input[name='openingHeight']").fill("2")
            page.locator("#fm-capture-opening-form input[name='sillHeight']").fill("3")
            page.locator("#fm-capture-opening-form button[type='submit']").click()
            assert "window · wall 1" in capture_dialog.inner_text().lower()
            page.locator("#fm-capture-next").click()
            page.locator("#fm-capture-affected-form input[name='floor']").check()
            page.locator("#fm-capture-affected-form input[name='wall']").first.check()
            quantities = page.evaluate("window.RoomFlowCapture.estimateQuantities(window.RoomFlowCapture.state.room)")
            assert quantities["floorSquareFeet"] > 0 and quantities["wallSquareFeet"] > 0
            cost = page.evaluate("window.RoomFlowCapture.calculateCost(window.RoomFlowCapture.state.room,{floorPerSquareFoot:2.5,wallPerSquareFoot:1.25})")
            assert cost["total"] > 0 and cost["lines"][0]["unit"] == "SF"
            page.locator("#fm-capture-next").click()
            page.wait_for_timeout(750)
            assert page.get_by_text("is saved.").is_visible(), f"capture save did not complete: {capture_dialog.inner_text()}; browser errors: {errors}"
            page.get_by_role("button", name="Done").click()
            assert capture_dialog.is_hidden()

            page.reload(wait_until="domcontentloaded")
            page.locator("#fm-capture-launch").wait_for(state="visible")
            page.locator("#fm-capture-launch").click()
            page.get_by_text("Basement Recreation Room").wait_for(state="visible")
            page.locator("#fm-capture-close").click()

            page.evaluate("""window.__captureBridgeMessages=[]; window.RoomFlowNativeBridge={postMessage(message){const envelope=typeof message==='string'?JSON.parse(message):message; window.__captureBridgeMessages.push(envelope); let payload={}; let type='sessionCompleted'; if(envelope.type==='capabilitiesRequested'){type='capabilitiesReported';payload={supported:true,modes:['android-arcore-guided','manual'],preferredMode:'android-arcore-guided',depthSupported:false,provider:'test'};} if(envelope.type==='captureRoomsRequested'){type='captureRoomsReported';payload={items:[]};} if(envelope.type==='captureOutboxReplayRequested'){type='captureOutboxReplayed';payload={complete:true,results:[]};} if(envelope.type==='roomCaptureStarted'){type='roomCaptureCompleted';payload={schemaVersion:2,sessionId:envelope.sessionId,jobId:envelope.payload.jobId,workspaceId:envelope.payload.workspaceId,levelId:envelope.payload.levelId,roomId:'bridge-room',name:envelope.payload.name,roomType:envelope.payload.roomType,units:'ft',height:8,vertices:[{id:'1',x:0,y:0,confidence:.8,depthValidated:false,source:'android-arcore-guided'},{id:'2',x:8,y:0,confidence:.8,depthValidated:false,source:'android-arcore-guided'},{id:'3',x:8,y:5,confidence:.8,depthValidated:false,source:'android-arcore-guided'},{id:'4',x:0,y:5,confidence:.8,depthValidated:false,source:'android-arcore-guided'}],openings:[],affectedAreas:[],scanMetadata:{captureMode:'android-arcore-guided',platform:'android',pointCount:4,averageConfidence:.8,depthValidatedPointCount:0,automaticCorrectionCount:0,manualCorrectionCount:0,verificationRequired:true,rawCaptureRetained:false}};} setTimeout(()=>window.RoomFlowCaptureBridgeV2.receive({version:2,sessionId:envelope.sessionId,type,requestId:envelope.requestId,ok:true,payload}),0);}}""")
            page.locator("#fm-capture-launch").click()
            page.get_by_role("button", name="Scan room with this device").wait_for(state="visible")
            page.get_by_role("button", name="Scan room with this device").click()
            page.locator("#fm-capture-prescan-form input[name='name']").fill("Bridge Capture Room")
            page.get_by_role("button", name="Start scanner").click()
            page.get_by_text("40 sq ft").first.wait_for(state="visible")
            bridge_envelope = page.evaluate("window.__captureBridgeMessages.find(value=>value.type==='roomCaptureStarted')")
            assert bridge_envelope["version"] == 2 and bridge_envelope["sessionId"] and bridge_envelope["payload"]["jobId"] == "browser-capture-job"
            page.locator("#fm-capture-close").click()
            page.evaluate("delete window.RoomFlowNativeBridge; localStorage.removeItem('floodman_roomflow_capture_draft_v2')")

            page.locator("#fm-capture-launch").click()
            page.evaluate("""window.RoomFlowCapture.acceptNativeResult({captureMode:'simulated-native',room:{units:'ft',roomId:'simulated-native-room',name:'Simulated Native Room',roomType:'bedroom',levelId:'main',height:8,vertices:[{x:0,y:0,confidence:.9},{x:6,y:0,confidence:.9},{x:6,y:6,confidence:.9},{x:0,y:6,confidence:.9}],openings:[],affectedAreas:[],scanMetadata:{captureMode:'simulated-native',platform:'android',pointCount:4,averageConfidence:.9,depthValidatedPointCount:0,automaticCorrectionCount:0,manualCorrectionCount:0,verificationRequired:true,rawCaptureRetained:false}}})""")
            page.get_by_text("36 sq ft").first.wait_for(state="visible")
            page.get_by_role("button", name="Compare captured plan").click()
            assert page.locator(".fm-capture-plan polygon.original").count() == 1
            page.locator("[data-lock-wall='0']").check()
            assert page.locator("[data-wall-length='0']").is_disabled()
            page.locator("[data-lock-wall='0']").uncheck()
            page.locator("[data-add-vertex='0']").click()
            assert page.locator("[data-plan-vertex]").count() == 5
            page.get_by_role("button", name="Undo").click()
            assert page.locator("[data-plan-vertex]").count() == 4
            page.locator("#fm-capture-close").click()

            page.locator("#fm-capture-launch").click()
            page.get_by_text("Recovered an unsaved room from this device").wait_for(state="visible")
            page.locator("#fm-capture-close").click()
            page.evaluate("localStorage.removeItem('floodman_roomflow_capture_draft_v2')")
            page.locator("#fm-capture-launch").click()
            page.get_by_role("button", name="Enter room manually").click()
            page.locator("#fm-capture-shape").select_option("l-shape")
            page.locator("#fm-capture-manual-form input[name='length']").fill("10")
            page.locator("#fm-capture-next").click()
            page.get_by_text("75 sq ft").first.wait_for(state="visible")
            page.locator("#fm-capture-close").click()

            page.locator("#more-new-company-name").fill("Browser RoomFlow Company")
            page.locator("#btn-more-create-company").click()
            page.wait_for_function("document.querySelector('#more-company-switcher')?.value && document.querySelector('#more-company-switcher')?.selectedOptions[0]?.textContent === 'Browser RoomFlow Company'")
            assert page.evaluate("window.__legacyAccountPrompted") is False
            assert page.locator("#auth-overlay").evaluate("node => getComputedStyle(node).display") == "none"
            assert "No separate RoomFlow account is needed" in page.locator("#more-company-switcher").locator("xpath=ancestor::*[contains(@class,'checklist-room-card')][1]").inner_text()
            guide = page.locator("#fm-rf-quick-start")
            assert guide.is_visible()
            page.locator("#fm-rf-guide-close").click()
            assert guide.is_hidden()
            page.locator("#fm-rf-help").click()
            assert guide.is_visible()
            assert page.locator(".fm-rf-details:not([open])").count() >= 3
            page.locator("#fm-rf-close-panel").click()
            assert page.locator("html").evaluate("node => node.classList.contains('fm-rf-panel-dismissed')")
            assert panel.get_attribute("aria-hidden") == "true"
            page.locator("#fm-rf-open-panel").click()
            assert panel.get_attribute("aria-hidden") == "false"
            page.keyboard.press("Escape")
            assert panel.get_attribute("aria-hidden") == "true"

            page.goto(base + "/legacy-roomflow?floodmanPanel=1", wait_until="domcontentloaded")
            page.locator("#fmrf-open").click()
            modal = page.locator("#fmrf-modal")
            modal.wait_for(state="visible")
            page.keyboard.press("Escape")
            assert modal.get_attribute("aria-hidden") == "true"
            page.locator("#fmrf-open").click()
            page.locator("#fmrf-close-icon").click()
            assert modal.get_attribute("aria-hidden") == "true"

            mobile_page = desktop.new_page()
            mobile_page.set_viewport_size({"width": 390, "height": 844})
            mobile_page.goto(base + "/office/mobile?mobile=1", wait_until="domcontentloaded")
            mobile_page.locator("[data-mobile-menu]").first.click()
            sidebar = mobile_page.locator("#fm-office-sidebar")
            assert sidebar.get_attribute("aria-hidden") == "false"
            mobile_page.keyboard.press("Escape")
            assert sidebar.get_attribute("aria-hidden") == "true"
            for path in ["/office/mobile?mobile=1", "/office/settings", "/office/contacts", "/office/properties", "/office/estimates", "/office/invoices", "/office/roomflow", "/office/roomflow/import"]:
                response = mobile_page.goto(base + path, wait_until="domcontentloaded")
                assert response and response.status == 200, f"mobile browser route failed: {path}"
                assert not mobile_page.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 2"), f"mobile horizontal overflow: {path}"

            mobile_page.goto(base + "/roomflow/", wait_until="domcontentloaded")
            mobile_page.locator("#fm-rf-help").click()
            assert mobile_page.locator("#fm-roomflow-panel").get_attribute("aria-hidden") == "false"
            assert mobile_page.locator("#fm-rf-quick-start").is_visible()
            assert not mobile_page.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 2"), "mobile RoomFlow horizontal overflow"
            mobile_page.locator("#fm-rf-close-panel").click()
            assert mobile_page.locator("#fm-roomflow-panel").get_attribute("aria-hidden") == "true"

            for width in (320, 360, 390, 430):
                mobile_page.set_viewport_size({"width": width, "height": 844})
                mobile_page.goto(base + "/roomflow/", wait_until="domcontentloaded")
                mobile_page.locator("#fm-capture-launch").wait_for(state="visible")
                mobile_page.locator("#fm-capture-launch").click()
                mobile_dialog = mobile_page.locator("#fm-capture-dialog")
                mobile_dialog.wait_for(state="visible")
                assert mobile_page.locator("#fm-capture-close").is_visible(), f"capture close is hidden at {width}px"
                assert mobile_dialog.evaluate("node => node.scrollWidth <= node.clientWidth + 2"), f"capture dialog overflow at {width}px"
                mobile_page.keyboard.press("Escape")
                assert mobile_dialog.is_hidden(), f"capture dialog did not close at {width}px"

            mobile_page.close()
            desktop.close()
            browser.close()
            assert not errors, f"browser page errors: {errors}"
    finally:
        server.should_exit = True
        thread.join(timeout=10)


def run() -> None:
    static_overlay_contracts()
    with tempfile.TemporaryDirectory() as temp:
        os.environ["OFFICE_CONSOLE_DATA_DIR"] = str(Path(temp) / "office")
        os.environ["DOCUMENTS_PATH"] = str(Path(temp) / "documents")
        os.environ["OFFICE_CONSOLE_PUBLIC_URL"] = "http://127.0.0.1"
        os.environ["FLOODMAN_CUSTOMER_PUBLIC_URL"] = "http://127.0.0.1/customer"
        os.environ["OFFICE_SESSION_COOKIE_SECURE"] = "false"
        os.environ["INTERNAL_HMAC_KEYS"] = "v1:MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTE="
        os.environ["AI_HMAC_KEYS"] = "ai-v1:MjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI="
        from app import main

        main.providers = FakeProviders()
        records = seed(main)
        route_smoke(main, records)
        browser_smoke(main)
    print("Floodman web routes, responsive layouts, and dismissible overlay smoke test passed")


if __name__ == "__main__":
    run()
