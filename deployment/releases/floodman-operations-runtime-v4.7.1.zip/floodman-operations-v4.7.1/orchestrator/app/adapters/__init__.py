"""Provider adapters."""
