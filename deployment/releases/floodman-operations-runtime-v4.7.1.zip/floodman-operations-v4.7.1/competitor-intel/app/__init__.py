"""Floodman competitor intelligence service."""
