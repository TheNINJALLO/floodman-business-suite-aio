from __future__ import annotations

import html
import json
from typing import Any, Iterable

from .auth import has_permission


NAV_GROUPS = [
    ("Command", [
        ("/office", "Command Center", "dashboard", "dashboard.view"),
        ("/office/apps", "All Applications", "apps", "apps.view"),
        ("/office/platform", "Floodman ERP", "platform", "apps.view"),
        ("/office/signing", "Signing Suite", "signing", "documents.view"),
    ]),
    ("Customers & Jobs", [
        ("/office/contacts", "Contacts", "contacts", "contacts.view"),
        ("/office/properties", "Properties", "properties", "properties.view"),
        ("/office/tasks", "Tasks", "tasks", "tasks.view"),
        ("/office/notes", "Notes", "notes", "notes.view"),
    ]),
    ("Sales & Billing", [
        ("/office/estimates", "Estimates", "estimates", "estimates.view"),
        ("/office/invoices", "Invoices", "invoices", "invoices.view"),
        ("/office/payments", "Payments", "payments", "payments.view"),
        ("/office/receivables", "Receivables", "receivables", "receivables.view"),
    ]),
    ("People & Communication", [
        ("/office/time", "Time Clock", "time", "time.self"),
        ("/office/members", "Members & Roles", "members", "members.manage"),
        ("/office/documents", "Documents & Signing", "documents", "documents.view"),
        ("/office/messages", "Messages", "messages", "messages.view"),
        ("/office/alerts", "Staff Alerts", "alerts", "alerts.view"),
    ]),
    ("Growth & Administration", [
        ("/office/intelligence", "AI Competitor Intelligence", "intelligence", "intelligence.view"),
        ("/office/imports", "Import Center", "imports", "imports.manage"),
        ("/office/linking", "Connections", "linking", "connections.manage"),
        ("/setup", "Setup", "setup", "connections.manage"),
    ]),
]


MOBILE_PRIMARY = [
    ("/office", "Home", "⌂", "dashboard", "dashboard.view"),
    ("/office/contacts", "Customers", "◎", "contacts", "contacts.view"),
    ("/office/properties", "Jobs", "⌑", "properties", "properties.view"),
    ("/office/invoices", "Billing", "$", "invoices", "invoices.view"),
]


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def money_cents(value: Any, currency: str = "USD") -> str:
    try:
        cents = int(value or 0)
    except (TypeError, ValueError):
        cents = 0
    prefix = "$" if str(currency).upper() == "USD" else f"{esc(currency)} "
    return f"{prefix}{cents / 100:,.2f}"


def money_units(value: Any, currency: str = "USD") -> str:
    try:
        units = float(value or 0)
    except (TypeError, ValueError):
        units = 0
    prefix = "$" if str(currency).upper() == "USD" else f"{esc(currency)} "
    return f"{prefix}{units:,.2f}"


def badge(value: Any, tone: str | None = None) -> str:
    text = str(value or "UNKNOWN")
    normalized = text.upper()
    if tone is None:
        if normalized in {"CONNECTED", "READY", "PAID", "ACTIVE", "ACTIVE_CUSTOMER", "COMPLETED", "ACCEPTED", "OPTED_IN", "FULLY_PAID", "OWNER"}:
            tone = "good"
        elif normalized in {"FAILED", "INVALID", "DISABLED", "DEAD", "DISPUTED", "PAST_DUE", "ERROR", "CLOSED"}:
            tone = "bad"
        elif normalized in {"PREVIEWED", "PENDING", "INVITED", "QUEUED", "PARTIALLY_PAID", "WARNING", "UNPAID", "RUNNING", "LEAD"}:
            tone = "warn"
        else:
            tone = "neutral"
    return f"<span class='badge {tone}'>{esc(text)}</span>"


def progress(checklist: dict[str, bool]) -> tuple[int, int, int]:
    keys = ["owner_created", "profile_saved", "connections_tested", "import_reviewed", "legal_reviewed", "messaging_reviewed"]
    done = sum(1 for key in keys if checklist.get(key))
    return done, len(keys), int(done / len(keys) * 100)


def json_pre(value: Any) -> str:
    return f"<pre>{esc(json.dumps(value, indent=2, default=str))}</pre>"


def table(headers: Iterable[str], rows: Iterable[Iterable[Any]], empty: str = "No records yet.") -> str:
    header_values = [str(value) for value in headers]
    row_values = [list(row) for row in rows]
    head = "".join(f"<th scope='col'>{esc(value)}</th>" for value in header_values)
    if not row_values:
        body = f"<tr class='empty-row'><td colspan='{len(header_values)}' class='empty'>{esc(empty)}</td></tr>"
    else:
        rendered_rows: list[str] = []
        for row in row_values:
            padded = row + [""] * max(0, len(header_values) - len(row))
            cells = "".join(
                f"<td data-label='{esc(header_values[index])}'>{str(value if value is not None else '')}</td>"
                for index, value in enumerate(padded[: len(header_values)])
            )
            rendered_rows.append(f"<tr>{cells}</tr>")
        body = "".join(rendered_rows)
    return f"<div class='table-wrap'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


OFFICE_JS = r"""
(() => {
  const sidebar = document.getElementById('fm-office-sidebar');
  const backdrop = document.getElementById('fm-office-backdrop');
  if (!sidebar || !backdrop) return;
  const controls = Array.from(document.querySelectorAll('[data-mobile-menu]'));
  const closeControls = Array.from(document.querySelectorAll('[data-mobile-menu-close]'));
  const setOpen = (open) => {
    sidebar.classList.toggle('is-open', open);
    backdrop.classList.toggle('is-open', open);
    document.documentElement.classList.toggle('fm-office-menu-open', open);
    sidebar.setAttribute('aria-hidden', open ? 'false' : 'true');
    controls.forEach((button) => button.setAttribute('aria-expanded', open ? 'true' : 'false'));
  };
  controls.forEach((button) => button.addEventListener('click', () => setOpen(!sidebar.classList.contains('is-open'))));
  closeControls.forEach((button) => button.addEventListener('click', () => setOpen(false)));
  backdrop.addEventListener('click', () => setOpen(false));
  sidebar.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => setOpen(false)));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setOpen(false); });
  const desktop = window.matchMedia('(min-width: 901px)');
  const updateMode = () => {
    if (desktop.matches) setOpen(false);
    sidebar.setAttribute('aria-hidden', desktop.matches ? 'false' : sidebar.classList.contains('is-open') ? 'false' : 'true');
  };
  if (desktop.addEventListener) desktop.addEventListener('change', updateMode); else desktop.addListener(updateMode);
  updateMode();
})();
"""


BASE_CSS = r"""
:root{--bg:#07111f;--panel:#101d2f;--panel2:#15263d;--line:#29415f;--text:#edf4ff;--muted:#9fb0c6;--accent:#32a7ff;--accent2:#67d5c4;--danger:#ff7878;--warn:#ffc65c;--good:#5be39d;--side:265px;--safe-bottom:env(safe-area-inset-bottom,0px);--safe-top:env(safe-area-inset-top,0px)}
*{box-sizing:border-box}html{min-width:0;background:var(--bg);scroll-behavior:smooth}body{margin:0;overflow-x:hidden;background:radial-gradient(circle at 80% -10%,#193b5e 0,#07111f 44%);color:var(--text);font-family:Segoe UI,Inter,Arial,sans-serif;min-height:100vh;-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}button,a,input,select,textarea{touch-action:manipulation}a{color:#8bd3ff;text-decoration:none;overflow-wrap:anywhere}a:hover{text-decoration:underline}.shell{display:grid;grid-template-columns:var(--side) minmax(0,1fr);min-height:100vh}.office-sidebar{background:#081426f5;border-right:1px solid var(--line);padding:18px 13px;position:sticky;top:0;height:100vh;overflow:auto;z-index:50}.sidebar-mobile-head{display:none}.brand{font-size:21px;font-weight:800;letter-spacing:.2px;margin:3px 8px 4px}.brand.big{font-size:28px;margin:0 0 18px}.subbrand{font-size:12px;color:var(--muted);margin:0 8px 18px}.nav-group{margin:15px 0 5px;padding:0 10px;color:#7792b0;font-size:10px;letter-spacing:1px;text-transform:uppercase;font-weight:800}nav a{display:block;padding:10px 11px;border-radius:10px;color:#cfe0f4;margin:2px 0;font-weight:650;font-size:14px}nav a:hover{background:#162b45;text-decoration:none}nav a.active{background:#1c5f91;color:white;box-shadow:inset 3px 0 0 #8dd6ff}.side-note{margin-top:17px;border:1px solid #5c512d;background:#2a2516;padding:11px;border-radius:10px;font-size:12px;color:#f5d984}.user-box{margin-top:18px;padding:12px;border:1px solid var(--line);border-radius:10px;background:#0a1728}.user-box strong{display:block}.user-box form{margin-top:9px}.mobile-topbar,.mobile-bottom-nav,.mobile-nav-backdrop{display:none}main{padding:24px 30px 54px;min-width:0;width:100%}header.page-header{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:18px}h1{font-size:31px;line-height:1.12;margin:0 0 5px}h2{font-size:20px;line-height:1.25;margin:0 0 14px}h3{font-size:16px;margin:0 0 10px}.muted{color:var(--muted)}.card{min-width:0;background:linear-gradient(160deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:14px;padding:18px;margin:0 0 16px;box-shadow:0 14px 35px #0004;overflow-wrap:anywhere}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));gap:14px}.grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}.metrics-grid{grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}.metric strong{display:block;font-size:27px;line-height:1.15;margin-top:7px;overflow-wrap:anywhere}.metric small{color:var(--muted)}.app-card{display:flex;flex-direction:column;min-height:170px}.app-card .actions{margin-top:auto}.badge{display:inline-block;max-width:100%;border-radius:999px;padding:4px 9px;font-size:12px;font-weight:750;border:1px solid #50657e;background:#1e3149;overflow-wrap:anywhere}.badge.good{color:#9ff4c9;border-color:#25744e;background:#0b3827}.badge.warn{color:#ffe1a1;border-color:#806321;background:#453312}.badge.bad{color:#ffc0c0;border-color:#873e3e;background:#471c24}.badge.neutral{color:#c9d7e8}.notice{border:1px solid #276d8d;background:#0d3044;border-radius:11px;padding:12px 14px;margin-bottom:16px;color:#bfeaff}.callout{border-left:4px solid var(--accent);background:#0b2035;padding:13px 15px;border-radius:8px;margin:12px 0;overflow-wrap:anywhere}.warning{border-left-color:var(--warn);background:#2a2516}.danger{border-left-color:var(--danger);background:#351b22}.success{border-left-color:var(--good);background:#0b2d22}button,.button{display:inline-flex;min-height:42px;align-items:center;justify-content:center;background:#1888d4;color:white;border:0;border-radius:9px;padding:10px 14px;font-weight:750;cursor:pointer;text-decoration:none;font:inherit}button:hover,.button:hover{filter:brightness(1.12);text-decoration:none}.button.secondary,button.secondary{background:#263e59}.button.good,button.good{background:#16754a}.button.danger,button.danger{background:#8b3540}.button.small,button.small{min-height:36px;padding:7px 10px;font-size:12px}label{display:block;font-size:13px;color:#c8d8ea;margin:0 0 6px}input,select,textarea{width:100%;min-width:0;background:#081426;color:var(--text);border:1px solid #46617f;border-radius:8px;padding:11px 12px;font:inherit}textarea{min-height:110px;resize:vertical}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.form-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.field{min-width:0}.field.full{grid-column:1/-1}.checks label{display:flex;gap:9px;align-items:flex-start;margin:9px 0}.checks input{width:auto;margin-top:3px}.table-wrap{max-width:100%;overflow:auto;border:1px solid var(--line);border-radius:11px;-webkit-overflow-scrolling:touch}table{width:100%;border-collapse:collapse;min-width:700px}th,td{padding:10px 12px;border-bottom:1px solid #263c58;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:#a9bdd4;background:#0a1728}td{font-size:14px}tr:last-child td{border-bottom:0}.empty{text-align:center;color:var(--muted);padding:24px}pre{white-space:pre-wrap;word-break:break-word;background:#06101d;border:1px solid #233a57;border-radius:9px;padding:12px;max-height:460px;overflow:auto}code{background:#071321;border:1px solid #28425f;border-radius:5px;padding:2px 5px}details{border:1px solid #29415f;border-radius:9px;padding:10px;margin:8px 0;background:#0a1728}summary{cursor:pointer;font-weight:700}.progress{height:12px;border-radius:999px;background:#091525;border:1px solid #29415f;overflow:hidden}.progress span{display:block;height:100%;background:linear-gradient(90deg,#1686d2,#5bd6bc)}.steps{display:grid;grid-template-columns:repeat(6,1fr);gap:7px;margin-top:9px}.step{text-align:center;font-size:12px;color:var(--muted);padding:7px;border-radius:7px;background:#0a1728}.step.done{color:#a7f0ce;background:#0d3528}.actions{display:flex;gap:9px;flex-wrap:wrap;align-items:center}.right{text-align:right}hr{border:0;border-top:1px solid var(--line);margin:18px 0}.mono{font-family:Consolas,monospace}.pill-list{display:flex;flex-wrap:wrap;gap:7px}.list-clean{margin:0;padding-left:20px}.auth-shell{min-height:100vh;display:grid;place-items:center;padding:20px}.auth-card{width:min(540px,100%);background:linear-gradient(160deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:16px;padding:28px;box-shadow:0 22px 60px #0008}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:15px}.tabs a{padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:#0a1728}.tabs a.active{background:#1c5f91;color:white}.split{display:grid;grid-template-columns:2fr 1fr;gap:16px}.creator-footer{margin-top:30px;padding:16px 0 0;border-top:1px solid var(--line);color:var(--muted);font-size:12px}.creator-footer a{color:#8bd3ff}img,svg,video{max-width:100%;height:auto}
@media(max-width:900px){.desktop-brand{display:none}html.fm-office-menu-open,html.fm-office-menu-open body{overflow:hidden}.shell{display:block;min-height:100vh}.office-sidebar{position:fixed;inset:0 auto 0 0;width:min(86vw,340px);height:100dvh;padding:calc(13px + var(--safe-top)) 13px calc(18px + var(--safe-bottom));border-right:1px solid var(--line);border-bottom:0;transform:translateX(-104%);transition:transform .22s ease;box-shadow:18px 0 55px #0009;z-index:1002}.office-sidebar.is-open{transform:translateX(0)}.sidebar-mobile-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}.sidebar-mobile-head .brand{margin:0}.mobile-close{width:44px;min-height:44px;padding:0;border-radius:50%;font-size:23px;background:#203853}.mobile-nav-backdrop{display:block;position:fixed;inset:0;z-index:1001;opacity:0;pointer-events:none;background:#020712b8;backdrop-filter:blur(3px);transition:opacity .2s}.mobile-nav-backdrop.is-open{opacity:1;pointer-events:auto}.mobile-topbar{position:sticky;top:0;z-index:900;display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:60px;padding:calc(8px + var(--safe-top)) 12px 8px;border-bottom:1px solid var(--line);background:#081426f2;backdrop-filter:blur(14px);box-shadow:0 8px 25px #0005}.mobile-topbar-brand{display:flex;align-items:center;gap:9px;min-width:0;font-weight:850}.mobile-topbar-mark{display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,#1d4ed8,#0ea5e9);font-size:19px}.mobile-topbar-copy{min-width:0}.mobile-topbar-copy b,.mobile-topbar-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mobile-topbar-copy small{color:var(--muted);font-size:10px;font-weight:600}.mobile-menu-button{width:46px;min-height:46px;padding:0;border-radius:12px;background:#1b3554;font-size:22px}.nav-group{display:block}.office-sidebar nav{display:block;overflow:visible}.office-sidebar nav a{min-height:44px;display:flex;align-items:center;white-space:normal}.mobile-bottom-nav{position:fixed;left:0;right:0;bottom:0;z-index:950;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));padding:6px 5px calc(6px + var(--safe-bottom));border-top:1px solid #31506f;background:#081426f7;backdrop-filter:blur(16px);box-shadow:0 -10px 30px #0007}.mobile-bottom-nav a,.mobile-bottom-nav button{min-width:0;min-height:54px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;border-radius:10px;padding:4px 2px;color:#a9bed5;background:transparent;font-size:10px;font-weight:750;text-decoration:none}.mobile-bottom-nav .mobile-nav-icon{font-size:20px;line-height:1}.mobile-bottom-nav a.active{color:white;background:#1a5482}.mobile-bottom-nav button{border:0}.mobile-bottom-nav a:hover{text-decoration:none}.mobile-bottom-nav span:last-child{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}main{padding:15px 12px calc(90px + var(--safe-bottom))}.page-header{display:block!important}.page-header h1{font-size:26px}.header-meta{margin-top:10px}.form-grid,.form-grid.three,.grid.two,.split{grid-template-columns:1fr}.steps{grid-template-columns:repeat(2,1fr)}input,select,textarea{min-height:48px;font-size:16px}textarea{min-height:130px}button,.button{min-height:48px}.auth-shell{padding:calc(16px + var(--safe-top)) 12px calc(16px + var(--safe-bottom))}.auth-card{padding:20px 16px;border-radius:14px}}
@media(max-width:720px){.card{padding:14px;border-radius:13px;margin-bottom:12px}.grid{gap:10px}.metric strong{font-size:23px}.actions{display:grid;grid-template-columns:1fr;width:100%}.actions>*,.actions form,.actions form button{width:100%}.tabs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.tabs a{text-align:center}.table-wrap{overflow:visible;border:0;border-radius:0;background:transparent}table{display:block;min-width:0}thead{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap}tbody{display:block}tbody tr{display:block;margin:0 0 11px;border:1px solid var(--line);border-radius:12px;background:#0a1728;box-shadow:0 8px 20px #0003;overflow:hidden}tbody td{display:grid;grid-template-columns:minmax(104px,38%) minmax(0,1fr);gap:10px;align-items:start;min-height:43px;padding:10px 11px;border-bottom:1px solid #203752;font-size:13px}tbody td::before{content:attr(data-label);color:#91aac5;font-size:10px;font-weight:850;letter-spacing:.06em;text-transform:uppercase;overflow-wrap:anywhere}tbody tr:last-child td,tbody td:last-child{border-bottom:0}tbody .empty{display:block;text-align:center;padding:20px}.empty::before{content:none}.right{text-align:left}.creator-footer{padding-bottom:4px}.notice,.callout{font-size:13px}}
@media(max-width:420px){main{padding-left:9px;padding-right:9px}.mobile-topbar{padding-left:9px;padding-right:9px}.card{padding:12px}.page-header h1{font-size:23px}.mobile-bottom-nav a,.mobile-bottom-nav button{font-size:9px}.mobile-bottom-nav .mobile-nav-icon{font-size:18px}tbody td{grid-template-columns:96px minmax(0,1fr);padding:9px}}
"""


def simple_page(title: str, body: str) -> str:
    return f"""<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#081426'><title>{esc(title)} · Floodman Operations</title><meta name='author' content='Josh Aldrich'><meta name='application-name' content='Floodman Operations'><style>{BASE_CSS}</style></head><body><div class='auth-shell'><div class='auth-card'><div class='brand big'>Floodman Operations</div><div class='subbrand'>Created by Josh Aldrich</div>{body}</div></div></body></html>"""


def layout(
    title: str,
    content: str,
    *,
    active: str = "dashboard",
    notice: str = "",
    setup_complete: bool = False,
    release: str = "",
    user: dict[str, Any] | None = None,
) -> str:
    nav_parts: list[str] = []
    for group, items in NAV_GROUPS:
        visible = [item for item in items if user is None or has_permission(user, item[3])]
        if not visible:
            continue
        nav_parts.append(f"<div class='nav-group'>{esc(group)}</div>")
        nav_parts.extend(
            f"<a class={'active' if key == active else ''!r} href='{href}'>{esc(label)}</a>"
            for href, label, key, _permission in visible
        )
    nav = "".join(nav_parts)
    notice_html = f"<div class='notice'>{esc(notice)}</div>" if notice else ""
    setup_chip = badge("Setup complete", "good") if setup_complete else badge("Setup in progress", "warn")
    if user:
        user_box = (
            f"<div class='user-box'><strong>{esc(user.get('name'))}</strong><span class='muted'>{esc(user.get('email'))}</span>"
            f"<div style='margin-top:7px'>{badge(user.get('role'))}</div>"
            "<form method='post' action='/logout'><button class='secondary small'>Sign out</button></form></div>"
        )
        mobile_user = esc(user.get("role") or "Member")
    else:
        user_box = ""
        mobile_user = "Secure operations"

    mobile_links: list[str] = []
    for href, label, icon, key, permission in MOBILE_PRIMARY:
        if user is not None and not has_permission(user, permission):
            continue
        mobile_links.append(
            f"<a href='{href}' class={'active' if active == key else ''!r}><span class='mobile-nav-icon'>{esc(icon)}</span><span>{esc(label)}</span></a>"
        )
    mobile_links.append("<button type='button' data-mobile-menu aria-label='Open all Floodman tools'><span class='mobile-nav-icon'>☰</span><span>More</span></button>")
    mobile_bottom = "".join(mobile_links)

    return f"""<!doctype html>
<html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><meta name='theme-color' content='#081426'>
<title>{esc(title)} · Floodman Operations</title><meta name='author' content='Josh Aldrich'><meta name='application-name' content='Floodman Operations'><style>{BASE_CSS}</style></head><body>
<div class='mobile-topbar'><div class='mobile-topbar-brand'><span class='mobile-topbar-mark'>F</span><span class='mobile-topbar-copy'><b>Floodman Operations</b><small>{mobile_user}</small></span></div><button class='mobile-menu-button' type='button' data-mobile-menu aria-label='Open navigation' aria-expanded='false'>☰</button></div>
<div id='fm-office-backdrop' class='mobile-nav-backdrop'></div>
<div class='shell'><aside id='fm-office-sidebar' class='office-sidebar' aria-hidden='false'>
<div class='sidebar-mobile-head'><div class='brand'>Floodman Operations</div><button class='mobile-close' type='button' data-mobile-menu-close aria-label='Close navigation'>×</button></div>
<div class='brand desktop-brand'>Floodman Operations</div><div class='subbrand'>Created by Josh Aldrich · {esc(release)}</div><nav>{nav}</nav>
<div class='side-note'><b>BUSINESS STAGING</b><br>Floodman runs in clean non-demo mode. Square, SMS, customer email, and production signatures remain local or sandboxed until explicitly connected.</div>{user_box}
</aside><main><header class='page-header'><div><h1>{esc(title)}</h1><div class='muted'>One command center for Floodman ERP, signing, receivables, RoomFlow, customer files, and AI intelligence.</div></div><div class='header-meta'>{setup_chip}</div></header>{notice_html}{content}<footer class='creator-footer'><b>Floodman Operations</b> · Created by Josh Aldrich · <a href='/floodman-third-party-notices.html' target='_blank'>Third-party notices</a></footer></main></div>
<nav class='mobile-bottom-nav' aria-label='Primary mobile navigation'>{mobile_bottom}</nav><script>{OFFICE_JS}</script></body></html>"""
