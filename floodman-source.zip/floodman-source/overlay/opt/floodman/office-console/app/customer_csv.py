from __future__ import annotations

import csv
import hashlib
import io
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from email_validator import EmailNotValidError, validate_email


MAX_CUSTOMER_ROWS = 50_000
MAX_CUSTOMER_CSV_BYTES = 25 * 1024 * 1024


class CustomerCsvError(ValueError):
    pass


HEADER_ALIASES: dict[str, set[str]] = {
    "external_id": {
        "customerid", "contactid", "clientid", "accountid", "id", "customernumber", "accountnumber",
        "legacycustomerid", "legacycontactid", "recordid",
    },
    "first_name": {"firstname", "first", "givenname", "customerfirstname", "contactfirstname"},
    "last_name": {"lastname", "last", "surname", "familyname", "customerlastname", "contactlastname"},
    "full_name": {"name", "fullname", "customername", "clientname", "contactname", "displayname"},
    "company": {"company", "business", "businessname", "organization", "organisation", "companyname"},
    "email": {"email", "emailaddress", "primaryemail", "customeremail", "contactemail"},
    "phone": {
        "phone", "phonenumber", "primaryphone", "mobile", "mobilenumber", "cell", "cellphone", "telephone",
        "customerphone", "contactphone", "homephone", "workphone",
    },
    "street": {
        "address", "address1", "street", "streetaddress", "serviceaddress", "billingaddress", "mailingaddress",
        "addressline1", "serviceaddress1", "customeraddress",
    },
    "street2": {"address2", "addressline2", "suite", "unit", "apartment", "serviceaddress2"},
    "city": {"city", "town", "servicecity", "billingcity", "mailingcity"},
    "state": {"state", "province", "region", "servicestate", "billingstate", "mailingstate"},
    "postal_code": {"zip", "zipcode", "postalcode", "postcode", "servicezip", "billingzip", "mailingzip"},
    "country": {"country", "countrycode"},
    "notes": {"notes", "note", "comments", "comment", "customernotes", "description"},
    "lead_source": {"leadsource", "source", "referral", "howheard", "marketingsource"},
    "created_at": {"createdat", "createddate", "datecreated", "customercreated", "addeddate"},
    "property_name": {"propertyname", "locationname", "sitename", "jobsite", "serviceproperty"},
}


def normalize_header(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())


def _decode(data: bytes) -> tuple[str, str]:
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    raise CustomerCsvError("The customer CSV must be UTF-8 or Windows-1252 encoded.")


def _dialect(text: str) -> csv.Dialect:
    sample = text[:64_000]
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        return csv.excel


def _header_mapping(headers: list[str]) -> tuple[dict[str, str], list[str]]:
    normalized = {header: normalize_header(header) for header in headers if str(header or "").strip()}
    mapped: dict[str, str] = {}
    used: set[str] = set()
    for canonical, aliases in HEADER_ALIASES.items():
        for header, key in normalized.items():
            if header in used:
                continue
            if key in aliases:
                mapped[canonical] = header
                used.add(header)
                break

    # Conservative fallback matching for common exports with prefixes/suffixes.
    fallbacks = {
        "email": ("email",),
        "phone": ("phone", "mobile", "cell"),
        "postal_code": ("zip", "postal"),
        "first_name": ("firstname",),
        "last_name": ("lastname",),
        "full_name": ("customername", "contactname", "fullname"),
        "street": ("streetaddress", "serviceaddress", "mailingaddress", "billingaddress"),
    }
    for canonical, needles in fallbacks.items():
        if canonical in mapped:
            continue
        for header, key in normalized.items():
            if header in used:
                continue
            if any(needle in key for needle in needles):
                mapped[canonical] = header
                used.add(header)
                break

    ignored = [header for header in headers if header not in used]
    return mapped, ignored


def _value(row: dict[str, str], mapping: dict[str, str], key: str) -> str:
    header = mapping.get(key)
    return str(row.get(header, "") if header else "").strip()


def _split_name(full_name: str) -> tuple[str, str]:
    value = re.sub(r"\s+", " ", full_name.strip())
    if not value:
        return "", ""
    if "," in value:
        last, first = [part.strip() for part in value.split(",", 1)]
        return first, last
    parts = value.split(" ")
    if len(parts) == 1:
        return parts[0], ""
    return " ".join(parts[:-1]), parts[-1]


def _phone_key(value: str) -> str:
    digits = re.sub(r"\D", "", value)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    return digits[-10:] if len(digits) >= 10 else digits


def _text_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def _dedupe_key(item: dict[str, Any]) -> str:
    if item.get("external_id"):
        return "external:" + _text_key(str(item["external_id"]))
    if item.get("email"):
        return "email:" + str(item["email"]).lower()
    phone = _phone_key(str(item.get("phone") or ""))
    if len(phone) >= 10:
        return "phone:" + phone
    address = "|".join(
        str(item.get(key) or "") for key in ("street", "city", "state", "postal_code")
    )
    return "name-address:" + _text_key(str(item.get("name") or "") + "|" + address)


def _fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True)
class CustomerCsvResult:
    summary: dict[str, Any]
    normalized: dict[str, Any]


def parse_customer_csv(data: bytes, filename: str = "customers.csv") -> CustomerCsvResult:
    if not data:
        raise CustomerCsvError("The customer CSV is empty.")
    if len(data) > MAX_CUSTOMER_CSV_BYTES:
        raise CustomerCsvError("The customer CSV exceeds the 25 MB limit.")

    text, encoding = _decode(data)
    reader = csv.DictReader(io.StringIO(text, newline=""), dialect=_dialect(text))
    headers = [str(value or "").strip() for value in (reader.fieldnames or [])]
    if not headers:
        raise CustomerCsvError("The customer CSV does not contain a header row.")
    mapping, ignored = _header_mapping(headers)
    if not ({"full_name", "first_name", "company"} & set(mapping)):
        raise CustomerCsvError(
            "No customer-name column was recognized. Include Name, Customer Name, First Name, or Company."
        )

    records: list[dict[str, Any]] = []
    errors: list[str] = []
    warnings: list[str] = []
    duplicate_rows: list[int] = []
    seen: set[str] = set()
    source_fingerprint = _fingerprint(data)

    for row_number, raw in enumerate(reader, start=2):
        if row_number > MAX_CUSTOMER_ROWS + 1:
            errors.append(f"The CSV exceeds {MAX_CUSTOMER_ROWS:,} customer rows.")
            break
        row = {str(key or "").strip(): str(value or "").strip() for key, value in raw.items()}
        if not any(row.values()):
            continue

        first_name = _value(row, mapping, "first_name")
        last_name = _value(row, mapping, "last_name")
        full_name = _value(row, mapping, "full_name")
        company = _value(row, mapping, "company")
        if not first_name and not last_name and full_name:
            first_name, last_name = _split_name(full_name)
        name = " ".join(value for value in (first_name, last_name) if value).strip() or full_name.strip() or company.strip()
        if not name:
            errors.append(f"Row {row_number}: customer name is empty.")
            continue

        email = _value(row, mapping, "email")
        if email:
            try:
                email = validate_email(email, check_deliverability=False).normalized
            except EmailNotValidError as exc:
                errors.append(f"Row {row_number}: invalid email {email!r}: {exc}")
                continue

        phone = _value(row, mapping, "phone")
        phone_digits = _phone_key(phone)
        if phone and len(phone_digits) < 10:
            warnings.append(f"Row {row_number}: phone number looks incomplete: {phone!r}.")

        record: dict[str, Any] = {
            "row_number": row_number,
            "external_id": _value(row, mapping, "external_id"),
            "first_name": first_name,
            "last_name": last_name,
            "name": name,
            "company": company,
            "email": email,
            "phone": phone,
            "street": _value(row, mapping, "street"),
            "street2": _value(row, mapping, "street2"),
            "city": _value(row, mapping, "city"),
            "state": _value(row, mapping, "state"),
            "postal_code": _value(row, mapping, "postal_code"),
            "country": _value(row, mapping, "country") or "US",
            "notes": _value(row, mapping, "notes"),
            "lead_source": _value(row, mapping, "lead_source"),
            "created_at": _value(row, mapping, "created_at"),
            "property_name": _value(row, mapping, "property_name"),
            "source_fingerprint": source_fingerprint,
        }
        key = _dedupe_key(record)
        record["dedupe_key"] = key
        if key in seen:
            duplicate_rows.append(row_number)
            continue
        seen.add(key)
        records.append(record)

    address_count = sum(1 for item in records if item.get("street"))
    email_count = sum(1 for item in records if item.get("email"))
    phone_count = sum(1 for item in records if item.get("phone"))
    company_count = sum(1 for item in records if item.get("company"))
    summary = {
        "import_kind": "CUSTOMERS_CSV",
        "filename": filename,
        "source_sha256": source_fingerprint,
        "encoding": encoding,
        "headers": headers,
        "column_mapping": mapping,
        "ignored_columns": ignored,
        "counts": {
            "rows_read": len(records) + len(duplicate_rows),
            "customers_ready": len(records),
            "duplicate_rows_skipped": len(duplicate_rows),
            "with_email": email_count,
            "with_phone": phone_count,
            "with_address": address_count,
            "companies": company_count,
        },
        "errors": errors,
        "warnings": warnings,
        "duplicate_rows": duplicate_rows[:500],
        "status": "PREVIEWED" if not errors else "INVALID",
    }
    normalized = {
        "import_kind": "CUSTOMERS_CSV",
        "source_sha256": source_fingerprint,
        "customers": records,
    }
    return CustomerCsvResult(summary=summary, normalized=normalized)


def customer_template() -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(
        [
            "customer_id",
            "first_name",
            "last_name",
            "company",
            "email",
            "phone",
            "address",
            "address_2",
            "city",
            "state",
            "zip",
            "notes",
            "lead_source",
        ]
    )
    writer.writerow(
        [
            "CUST-1001",
            "Jane",
            "Example",
            "",
            "jane@example.com",
            "555-555-0101",
            "123 Main Street",
            "",
            "Detroit",
            "MI",
            "48201",
            "Previous waterproofing customer",
            "Referral",
        ]
    )
    return output.getvalue().encode("utf-8")
